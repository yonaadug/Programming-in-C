This tests a 2 by 2 matrix.  

