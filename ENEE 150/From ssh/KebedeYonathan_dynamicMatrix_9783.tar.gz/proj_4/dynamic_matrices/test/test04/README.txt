This test makes matrices that have negative numbers and uses transpose
