This test adds, two empty matrices
