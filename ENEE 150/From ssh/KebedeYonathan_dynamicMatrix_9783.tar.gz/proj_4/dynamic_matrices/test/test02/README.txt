This test is for invalid first character input.
