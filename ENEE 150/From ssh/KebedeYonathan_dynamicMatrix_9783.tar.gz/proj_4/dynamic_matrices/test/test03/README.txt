This test inputs the ascii for the character 'A' to make a 2x2 matrix for 'A'
