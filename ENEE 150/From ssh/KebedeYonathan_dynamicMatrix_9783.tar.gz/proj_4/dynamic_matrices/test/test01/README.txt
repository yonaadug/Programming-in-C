This test makes 3 matrices and uses transpose, multiplication and addition between the matrices.

