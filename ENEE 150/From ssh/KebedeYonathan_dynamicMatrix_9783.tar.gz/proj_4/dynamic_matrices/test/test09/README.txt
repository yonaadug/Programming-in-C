This test makes to matrices that have 0 for their rows and columns.
