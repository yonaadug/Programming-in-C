This test makes 4x4 matrix 'A' then remakes it with a smaller matrix
