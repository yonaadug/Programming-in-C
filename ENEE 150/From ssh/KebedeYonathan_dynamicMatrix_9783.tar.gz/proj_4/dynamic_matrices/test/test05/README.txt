This test puts negative numbers for rows and columns.
