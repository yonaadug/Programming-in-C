This test multiplies 2 empty matrices with one testing and invalid matrix 'E'
