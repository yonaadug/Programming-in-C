This test makes an incomplete matrix and transposes it
