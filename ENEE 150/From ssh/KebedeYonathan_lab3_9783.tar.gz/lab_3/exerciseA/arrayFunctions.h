
/* header file: arrayFunctions.h */

double median_array (double [ ], int );
void  bubble_sort( double [ ], int );
double  mean_array (double [ ], int );


