This test is for varying input order

