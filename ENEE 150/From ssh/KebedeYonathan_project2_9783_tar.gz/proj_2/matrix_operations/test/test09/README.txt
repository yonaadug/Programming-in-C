This test is for an incomplete set of elements for building the matrix.  

