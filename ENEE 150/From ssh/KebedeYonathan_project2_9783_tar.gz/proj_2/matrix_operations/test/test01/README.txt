This tests a single element matrix  

