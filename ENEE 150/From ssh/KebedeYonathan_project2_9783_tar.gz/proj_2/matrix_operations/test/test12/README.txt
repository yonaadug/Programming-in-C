This tests when the user enters a negative number of colummns.

