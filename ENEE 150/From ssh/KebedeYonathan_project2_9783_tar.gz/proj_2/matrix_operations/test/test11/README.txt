This test is for more than the max number of rows.

