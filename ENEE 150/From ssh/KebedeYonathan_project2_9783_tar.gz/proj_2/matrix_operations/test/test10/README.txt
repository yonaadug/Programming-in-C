This tests if the max number of columns is entered. 

