This test is for a mix of positive, negative and zero valued elements.

