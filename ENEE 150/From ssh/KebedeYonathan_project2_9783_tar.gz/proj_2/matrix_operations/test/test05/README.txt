This test is for a matrix with all 0's

