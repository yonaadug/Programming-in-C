This tests if the program outputs the correct fraction.


