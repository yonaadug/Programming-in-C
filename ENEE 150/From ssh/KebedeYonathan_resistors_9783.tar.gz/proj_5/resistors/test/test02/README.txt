This test is testing negative resistance

