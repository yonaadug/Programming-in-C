This test is for entering same ID resistors

