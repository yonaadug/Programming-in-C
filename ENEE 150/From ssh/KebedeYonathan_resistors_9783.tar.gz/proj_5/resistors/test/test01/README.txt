This test is for exiting

