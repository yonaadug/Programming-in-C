Automatically-generated test-output directory
