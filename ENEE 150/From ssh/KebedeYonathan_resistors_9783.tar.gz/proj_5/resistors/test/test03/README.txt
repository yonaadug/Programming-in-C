This test is testing negative resistor ID

