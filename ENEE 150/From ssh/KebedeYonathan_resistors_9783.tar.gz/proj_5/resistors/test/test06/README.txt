This test tries to delete a resistor that doesnt exist.

