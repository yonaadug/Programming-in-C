This test is testing deletion of resistors.

